"""Vercel Python function: free, keyless Edge TTS voice-over synthesis.

Important: this uses the unofficial edge-tts library and an external online
speech service. Availability, usage policy, and pricing are not guaranteed.
"""
from __future__ import annotations

import asyncio
import hmac
import json
import os
from http.server import BaseHTTPRequestHandler

VOICES = frozenset({
    'id-ID-ArdiNeural',
    'id-ID-GadisNeural',
    'su-ID-JajangNeural',
    'su-ID-TutiNeural',
    'en-US-GuyNeural',
    'en-US-JennyNeural',
    'ar-SA-HamedNeural',
    'ar-SA-ZariyahNeural',
})
MAX_TEXT_LENGTH = 2000
MAX_REQUEST_BYTES = 10000
MAX_AUDIO_BYTES = 12 * 1024 * 1024


class ClientError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def validate_payload(data: object) -> tuple[str, str, int, int, int]:
    if not isinstance(data, dict):
        raise ClientError('Format permintaan harus JSON object.')
    text = data.get('text')
    if not isinstance(text, str) or not text.strip():
        raise ClientError('Isi naskah terlebih dahulu.')
    text = text.strip()
    if len(text) > MAX_TEXT_LENGTH:
        raise ClientError('Maksimal 2.000 karakter per proses.')
    voice = data.get('voice_id')
    if voice not in VOICES:
        raise ClientError('Pilihan suara tidak tersedia.')

    def setting(name, low, high):
        value = data.get(name, 0)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ClientError(f'Pengaturan {name} tidak valid.')
        value = int(value)
        if not low <= value <= high:
            raise ClientError(f'Pengaturan {name} di luar batas.')
        return value

    rate = setting('rate', -50, 50)
    pitch = setting('pitch', -50, 50)
    volume = setting('volume', -50, 50)
    return text, voice, rate, pitch, volume


async def synthesize_audio(text: str, voice: str, rate: int, pitch: int, volume: int) -> bytes:
    """Collect MP3 chunks from edge-tts with an upper bound."""
    import edge_tts

    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=f'{rate:+d}%',
        pitch=f'{pitch:+d}Hz',
        volume=f'{volume:+d}%',
    )
    chunks = []
    size = 0
    async for chunk in communicate.stream():
        if chunk.get('type') == 'audio':
            buf = chunk.get('data', b'')
            if not isinstance(buf, bytes):
                continue
            size += len(buf)
            if size > MAX_AUDIO_BYTES:
                raise RuntimeError('Audio terlalu besar.')
            chunks.append(buf)
    result = b''.join(chunks)
    if not result:
        raise RuntimeError('Layanan suara tidak mengirim audio.')
    return result


class handler(BaseHTTPRequestHandler):
    def send_json(self, status: int, message: str):
        body = json.dumps({'error': message}, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self.send_json(405, 'Gunakan metode POST.')

    def do_POST(self):
        expected = os.environ.get('APP_ACCESS_TOKEN')
        if expected and not hmac.compare_digest(self.headers.get('x-app-token', ''), expected):
            self.send_json(401, 'Kode akses aplikasi tidak cocok.')
            return
        try:
            length_str = self.headers.get('Content-Length', '')
            try:
                length = int(length_str)
            except ValueError:
                raise ClientError('Content-Length tidak valid.', 411)
            if length <= 0 or length > MAX_REQUEST_BYTES:
                raise ClientError('Permintaan terlalu besar atau kosong.', 413)
            data = json.loads(self.rfile.read(length).decode('utf-8'))
            text, voice, rate, pitch, volume = validate_payload(data)
        except ClientError as err:
            self.send_json(err.status, str(err))
            return
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json(400, 'JSON tidak valid.')
            return
        try:
            audio = asyncio.run(asyncio.wait_for(
                synthesize_audio(text, voice, rate, pitch, volume),
                timeout=45.0,
            ))
        except (TimeoutError, asyncio.TimeoutError):
            self.send_json(504, 'Layanan suara terlalu lama merespons. Ulangi nanti.')
            return
        except Exception:
            self.send_json(502, 'Gagal menjangkau layanan suara gratis. Coba lagi nanti atau gunakan pratinjau browser.')
            return
        self.send_response(200)
        self.send_header('Content-Type', 'audio/mpeg')
        self.send_header('Content-Length', str(len(audio)))
        self.send_header('Content-Disposition', 'inline; filename="voice-over.mp3"')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(audio)
