# VOICE OVER AI PRO — FREE 🎙️

Aplikasi web **gratis tanpa API key** untuk membuat voice over. Ini **versi 2.0** yang menggantikan paket lama berbasis ElevenLabs.

## Dua mode

1. **▶ Dengarkan Gratis (Browser)** — menggunakan Web Speech API yang sudah disediakan browser/perangkat. Tombol ini berfungsi saat `index.html` dibuka di komputer/HP yang mendukung `speechSynthesis`. Tidak perlu backend, login, API key, atau proses instalasi. **Tidak mendukung pengunduhan MP3**, dan suara yang digunakan bisa berbeda dari pilihan Edge TTS karena bergantung pada perangkat.
2. **✦ Buat & Unduh MP3 Gratis** — menggunakan library Python [`edge-tts`](https://github.com/rany2/edge-tts) pada backend untuk menghasilkan MP3 dan memutar/menyimpan file. Butuh **hosting yang mendukung Python** dan koneksi internet. Tidak memakai API key, tidak memakai kredit ElevenLabs.

## Fitur

- 8 pilihan neural TTS: **Indonesia** Ardi/Gadis, **Sunda** Jajang/Tuti, **Inggris** Guy/Jenny, **Arab** Hamed/Zariyah. Ketersediaan suara tergantung layanan.
- Slider kecepatan, nada, dan volume; contoh naskah edukasi, motivasi, dan puisi.
- MP3 dimainkan dan diunduh langsung, riwayat maksimal 8 hasil selama tab dibuka.
- Dashboard responsif dengan navigasi kiri dan workspace kanan pada komputer.
- Backend hanya menerima pilihan suara dalam daftar, maksimal 2.000 karakter, batas ukuran request dan audio, serta timeout.
- Kode akses internal opsional melalui `APP_ACCESS_TOKEN` (kode bersama, bukan akun pengguna).

## Langsung coba gratis di HP/komputer

1. Buka `index.html` di browser Chrome atau Edge.
2. Tulis naskah, pilih bahasa/suara, lalu tekan **Dengarkan Gratis (Browser)**.
3. Suara browser tergantung dukungan bahasa dan paket suara yang terpasang pada perangkat; jika bahasa yang dipilih tidak tersedia, pengucapan dapat kurang tepat.

## Aktifkan unduh MP3 dengan Vercel

1. Ekstrak ZIP, unggah isi folder ke repositori GitHub **privat**. Impor ke [Vercel](https://vercel.com/new) sebagai proyek baru dengan framework **Other**.
2. Biarkan file `api/tts.py`, `requirements.txt` dan `index.html` berada dalam root proyek. Vercel Python Runtime menerima handler `BaseHTTPRequestHandler` dan menginstal `requirements.txt` otomatis.
3. **Tidak perlu API key ElevenLabs atau kunci TTS apa pun.** Untuk pemakaian internal, Anda bisa menambahkan `APP_ACCESS_TOKEN` di Environment Variables Vercel dan memasukkan kode sama pada aplikasi.
4. Lakukan deploy. Dari URL situs, tombol Buat MP3 akan memanggil `/api/tts`.
5. Bila situs ingin ditampilkan di Google Sites, sematkan URL deployment (bukan membuat ChatGPT Sites secara otomatis).

> **Catatan penting:** `edge-tts` menggunakan layanan suara online Microsoft melalui antarmuka **tidak resmi**, bukan API Azure Speech resmi. Metode ini tidak menjanjikan akses tanpa batas, uptime, atau hak penggunaan komersial. Layanan dapat berubah atau membatasi akses kapan saja. Hosting Vercel mungkin juga memiliki batas kuota/biaya menurut penggunaan. Gunakan hanya sesuai ketentuan yang berlaku. Jika memerlukan aplikasi publik stabil, gunakan API TTS resmi atau model TTS offline berlisensi sesuai kebutuhan.

## Pengujian backend

Python 3.12+ disarankan. Setelah menyiapkan lingkungan Python:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Pengujian menggunakan mock suara dan tidak perlu akses internet. Untuk integrasi nyata, deploy atau jalankan server HTTP yang mendukung function, kemudian coba MP3 dengan koneksi internet. Tidak ada pengujian audio online yang diklaim berhasil di paket ini.

## Struktur

```
index.html             UI; preview browser dapat digunakan lokal
api/tts.py             Backend TTS Python untuk Vercel
requirements.txt       edge-tts
.env.example           Opsional APP_ACCESS_TOKEN saja
package.json           Metadata dan perintah Vercel CLI
.gitignore             Mengabaikan .env
README.md              Panduan ini
tests/test_tts.py       Unit testing tanpa internet
```

Sumber: https://github.com/rany2/edge-tts, https://vercel.com/docs/functions/runtimes/python, https://developer.mozilla.org/en-US/docs/Web/API/SpeechSynthesis
