import asyncio
import io
import json
import os
import threading
import unittest
from http.server import HTTPServer
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from api.tts import ClientError, handler, validate_payload


class BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.http = HTTPServer(('127.0.0.1', 0), handler)
        cls.port = cls.http.server_port
        cls.thread = threading.Thread(target=cls.http.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown()
        cls.http.server_close()
        cls.thread.join(timeout=2)

    def api(self, body=None, headers=None, method='POST'):
        url = f'http://127.0.0.1:{self.port}/api/tts'
        b = json.dumps(body or {}).encode('utf-8') if method == 'POST' else None
        request = Request(url, data=b, headers={'Content-Type': 'application/json', **(headers or {})}, method=method)
        try:
            with urlopen(request, timeout=3) as res:
                return res.status, dict(res.headers), res.read()
        except HTTPError as err:
            return err.code, dict(err.headers), err.read()

    def valid(self):
        return {'text': 'Halo Indonesia!', 'voice_id': 'id-ID-ArdiNeural', 'rate': 0, 'pitch': 0, 'volume': 0}

    def test_01_get_rejected(self):
        code, _, data = self.api(method='GET')
        self.assertEqual(code, 405)

    def test_02_empty_text(self):
        code, _, data = self.api({**self.valid(), 'text': ''})
        self.assertEqual(code, 400)

    def test_03_unsupported_voice(self):
        code, _, data = self.api({**self.valid(), 'voice_id': 'malicious'})
        self.assertEqual(code, 400)

    def test_04_out_of_range_settings(self):
        with self.assertRaises(ClientError):
            validate_payload({**self.valid(), 'rate': 100})

    def test_05_optional_access_code(self):
        with patch.dict(os.environ, {'APP_ACCESS_TOKEN': 'private-code'}):
            code, _, data = self.api(self.valid(), headers={'x-app-token':'wrong'})
            self.assertEqual(code, 401)

    def test_06_mock_mp3_response(self):
        async def mock_speech(*args):
            return b'ID3' + bytes([0,0,0,0])
        with patch('api.tts.synthesize_audio', new=mock_speech):
            code, headers, data = self.api(self.valid())
        self.assertEqual(code, 200)
        self.assertEqual(headers.get('Content-Type'), 'audio/mpeg')
        self.assertTrue(data.startswith(b'ID3'))

    def test_07_service_error(self):
        async def fail(*args):
            raise OSError('upstream failed')
        with patch('api.tts.synthesize_audio', new=fail):
            code, headers, data = self.api(self.valid())
        self.assertEqual(code, 502)
        self.assertIn('error', json.loads(data))


if __name__ == '__main__':
    unittest.main()
